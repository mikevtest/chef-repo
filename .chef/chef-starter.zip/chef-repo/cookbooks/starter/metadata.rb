name 'starter'
description 'A basic starter cookbook'
version '1.0.0'
